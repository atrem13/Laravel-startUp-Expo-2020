<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <style>
        .myBanner {
            height:700px;
            background-image: url("/myAssets/banner/IMG_8557.JPG");
            background-size: cover;
        }
        .myBannerTitle{
            margin-top: 16.5%;
        }
        .myBannerTitle h1{
            text-shadow: 0 3px 10px black;
        }
        .clearMP {
          padding: 0;
          margin:0;
        }
        .atTopLeft {
          position: absolute;
          top: 0;
          left: 0;
        }
        .atBottomRight {
          position: absolute;
          bottom: 0;
          right: 0;
        }
        .parentRelative{
          position: relative;
        }
        .intervalSection{
            padding: 120px 0;
        }
        .zig{
            background-color: rgba(0, 0, 0, 0.05);
        }
    </style>
</head>
<body>
    {{--  banner section  --}}
    <div class="container-fluid myBanner " id="home">
      <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
          <a class="navbar-brand" href="#">
              {{--  Navbar      --}}
              <img src="{{asset('myAssets/navLogo/2.png')}}" width="70px" height="30px" alt="navLogo">
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#myNav" aria-controls="myNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="myNav">
            <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
              <li class="nav-item ">
                <a class="nav-link" href="#home">Home <span class="fa fa-chevron-right"></span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#about">About us <span class="fa fa-chevron-right"></span></a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="#event">Event <span class="fa fa-chevron-right"></span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#tenant">Tenant <span class="fa fa-chevron-right"></span></a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="#galery">Galery <span class="fa fa-chevron-right"></span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact us <span class="fa fa-chevron-right"></span></a>
              </li>
            </ul>
          </div>
      </nav>
      <div class="container text-center text-white" style="padding-top:80px">
          <div class="myBannerTitle">
              <h1 class="display-3">Startup Expo</h1>
              <h1 class="display-3">STMIK Primakara</h1>
          </div>
      </div>
    </div>

    {{--  about us section  --}}
    <div class="container-fluid" id="about">
      <div class="container intervalSection">
        <div class="row">
          <div class="col-md-4 offset-md-2 col-sm-12">
            <img src="{{asset('myAssets/aboutUs/IMG_9890.JPG')}}" class="img-fluid" alt="pak made artana">
          </div>
          <div class="col-sm-12 col-md-6">
            <h3>Apa sih Startup Expo itu?</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima tenetur impedit assumenda, mollitia optio provident facere aliquam itaque, odit officiis harum molestias quis dolore asperiores ab in enim! Velit, nam.</p>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sequi id possimus molestiae maiores ipsam veniam placeat nobis, alias ratione qui provident, quia doloribus, sed est sit cupiditate ea quibusdam nulla.</p>
          </div>
        </div>
      </div>
    </div>

    {{-- event section --}}
    <div class="container-fluid zig" id="event">
      <div class="container intervalSection" >
        <h2 class="display-4 text-center mb-5">Ada event apa aja sih hari ini?</h2>
        <div class="row">
          <div class="col-md-4 col-sm-12 mb-5">
            <div class="card bg-dark text-white parentRelative">
              <img src="{{asset('myAssets/event/IMG_9900.JPG')}}" class="card-img" alt="...">
              <div class="card-img-overlay">
                <h5 class="card-title btn btn-dark atTopLeft" >Card title</h5>
                <p class="atBottomRight clearMP"><a href="" class="btn btn-dark">See more</a></p>
              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-12 mb-5">
            <div class="card bg-dark text-white parentRelative">
              <img src="{{asset('myAssets/event/IMG_9903.JPG')}}" class="card-img" alt="...">
              <div class="card-img-overlay">
                <h5 class="card-title btn btn-dark atTopLeft">Card title</h5>
                <p class="clearMP atBottomRight"><a href="" class="btn btn-dark">See more</a></p>
              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-12 mb-5">
            <div class="card bg-dark text-white parentRelative">
              <img src="{{asset('myAssets/event/_DSC0189.JPG')}}" class="card-img" alt="...">
              <div class="card-img-overlay">
                <h5 class="card-title btn btn-dark atTopLeft">Card title</h5>
                <p class="clearMP atBottomRight"><a href="" class="btn btn-dark">See more</a></p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

    {{-- tenant section --}}
    <?php /*
    <div class="container-fluid">
      <div class="container" style="margin:100px">
        <div class="row">
          {{-- tenant galery --}}
          <div class="col-sm-12 col-md-7">
            <div class="row">
              {{-- tenant col--}}
              {{-- tenant 1 --}}
              <div class="col-md-6 col-sm-6 mb-4">
                <!--Modal-->
                <div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby = "myModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg" role="document">

                    <!--Content-->
                    <div class="modal-content">
                      {{-- header --}}
                      <div class="modal-header">
                        {{-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> --}}
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <!--Body-->
                      <div class="modal-body mb-0 p-0">
                        <div class="container">
                          <div class="row mt-4">
                            <div class="col-sm-12 col-md-6">
                              <h3>Nama Tenant</h3>
                              <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Temporibus fugit aliquid qui illum molestias hic ipsa! Pariatur iste dolore, veniam quae sed quaerat minus necessitatibus delectus voluptatem harum magnam beatae.</p>
                              <p>kategori bisnis: </p>
                              <p><a href="">Link web</a></p>
                              <br>
                            </div>
                            <div class="col-sm-12 col-md-6">
                              <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
                                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/A3PDXmYoF5U"
                                  allowfullscreen></iframe>
                              </div>
                            </div>
                          </div>
                        </div>

                      </div>

                      <!--Footer-->
                      <div class="modal-footer justify-content-center">
                        <button class="btn btn-danger"><span class="fa fa-heart"></span> Like</button>
                      </div>

                    </div>
                    <!--/.Content-->

                  </div>
                </div>
                <!--Modal-->

                {{-- modal trigger --}}
                <div class="card" data-toggle="modal" data-target="#modal1" >
                  <img src="{{asset('myAssets/tenant/IMG_8488.JPG')}}" class="card-img-top" alt="...">
                  <div class="card-footer">
                    <p class="text-center">Nama Tenant</p>
                  </div>
                </div>
              </div>
              <!-- end tenant 1 -->

              {{-- tenant 2 --}}
              <div class="col-md-6 col-sm-6 mb-4">
                <!--Modal-->
                <div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby = "myModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg" role="document">

                    <!--Content-->
                    <div class="modal-content">
                      {{-- header --}}
                      <div class="modal-header">
                        {{-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> --}}
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <!--Body-->
                      <div class="modal-body mb-0 p-0">
                        <div class="container">
                          <div class="row mt-4">
                            <div class="col-sm-12 col-md-6">
                              <h3>Nama Tenant</h3>
                              <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Temporibus fugit aliquid qui illum molestias hic ipsa! Pariatur iste dolore, veniam quae sed quaerat minus necessitatibus delectus voluptatem harum magnam beatae.</p>
                              <p>kategori bisnis: </p>
                              <p><a href="">Link web</a></p>
                              <br>
                            </div>
                            <div class="col-sm-12 col-md-6">
                              <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
                                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/A3PDXmYoF5U"
                                  allowfullscreen></iframe>
                              </div>
                            </div>
                          </div>
                        </div>

                      </div>

                      <!--Footer-->
                      <div class="modal-footer justify-content-center">
                        <button class="btn btn-danger"><span class="fa fa-heart"></span> Like</button>
                      </div>

                    </div>
                    <!--/.Content-->

                  </div>
                </div>
                <!--Modal-->

                {{-- modal trigger --}}
                <div class="card" data-toggle="modal" data-target="#modal2" >
                  <img src="{{asset('myAssets/tenant/IMG_9999.JPG')}}" class="card-img-top" alt="...">
                  <div class="card-footer">
                    <p class="text-center">Nama Tenant</p>
                  </div>
                </div>
              </div>
              <!-- end tenant 2 -->

              {{-- tenant 3 --}}
              <div class="col-md-6 col-sm-6 mb-4">
                <!--Modal-->
                <div class="modal fade" id="modal3" tabindex="-1" role="dialog" aria-labelledby = "myModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg" role="document">

                    <!--Content-->
                    <div class="modal-content">
                      {{-- header --}}
                      <div class="modal-header">
                        {{-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> --}}
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <!--Body-->
                      <div class="modal-body mb-0 p-0">
                        <div class="container">
                          <div class="row mt-4">
                            <div class="col-sm-12 col-md-6">
                              <h3>Nama Tenant</h3>
                              <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Temporibus fugit aliquid qui illum molestias hic ipsa! Pariatur iste dolore, veniam quae sed quaerat minus necessitatibus delectus voluptatem harum magnam beatae.</p>
                              <p>kategori bisnis: </p>
                              <p><a href="">Link web</a></p>
                              <br>
                            </div>
                            <div class="col-sm-12 col-md-6">
                              <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
                                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/A3PDXmYoF5U"
                                  allowfullscreen></iframe>
                              </div>
                            </div>
                          </div>
                        </div>

                      </div>

                      <!--Footer-->
                      <div class="modal-footer justify-content-center">
                        <button class="btn btn-danger"><span class="fa fa-heart"></span> Like</button>
                      </div>

                    </div>
                    <!--/.Content-->

                  </div>
                </div>
                <!--Modal-->

                {{-- modal trigger --}}
                <div class="card" data-toggle="modal" data-target="#modal3" >
                  <img src="{{asset('myAssets/tenant/IMG_8518.JPG')}}" class="card-img-top" alt="...">
                  <div class="card-footer">
                    <p class="text-center">Nama Tenant</p>
                  </div>
                </div>
              </div>
              <!-- end tenant 3 -->
            </div>
          </div>
          {{-- end col-md-8 col-sm-12 / tenant galery section --}}


          <div class="col-sm-12 col-md-4 text-right my-auto">
            <h2 class="">Tenant-tenant di Startup Expo 2020</h2>
          </div>
        </div>
      </div>
    </div>
    */ ?>
    <div class="container-fluid" id="tenant">
        <div class="container intervalSection">
          <div class="row">
            {{-- tenant galery --}}
            <div class="col-sm-12 col-md-7">
                <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner text-white">
                      <div class="carousel-item active">
                        <img src="{{asset('myAssets/tenant/IMG_8488.JPG')}}" class="d-block w-100" alt="...">
                        <h5 class="btn btn-dark atTopLeft">Nama Tenant</h5>
                        <p class="atBottomRight clearMP"><a class="btn btn-dark " data-toggle="modal" data-target="#tenantDetail" >See More</a></p>
                      </div>
                      <div class="carousel-item">
                        <img src="{{asset('myAssets/tenant/IMG_8518.JPG')}}" class="d-block w-100" alt="...">
                        <h5 class="btn btn-dark atTopLeft">Nama Tenant</h5>
                        <p class="atBottomRight clearMP"><a class="btn btn-dark " data-toggle="modal" data-target="#tenantDetail" >See More</a></p>
                      </div>
                      <div class="carousel-item">
                        <img src="{{asset('myAssets/tenant/IMG_9999.JPG')}}" class="d-block w-100" alt="...">
                        <h5 class="btn btn-dark atTopLeft">Nama Tenant</h5>
                        <p class="atBottomRight clearMP"><a class="btn btn-dark " data-toggle="modal" data-target="#tenantDetail" >See More</a></p>
                      </div>
                    </div>
                </div>

                {{-- modal --}}
                <div class="modal fade" id="tenantDetail" tabindex="-1" role="dialog" aria-labelledby = "myModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">

                      <!--Content-->
                      <div class="modal-content">
                        {{-- header --}}
                        <div class="modal-header">
                          {{-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> --}}
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <!--Body-->
                        <div class="modal-body mb-0 p-0">
                          <div class="container">
                            <div class="row mt-4">
                              <div class="col-sm-12 col-md-6">
                                <h3>Nama Tenant</h3>
                                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Temporibus fugit aliquid qui illum molestias hic ipsa! Pariatur iste dolore, veniam quae sed quaerat minus necessitatibus delectus voluptatem harum magnam beatae.</p>
                                <p>kategori bisnis: </p>
                                <p><a href="">Link web</a></p>
                                <br>
                              </div>
                              <div class="col-sm-12 col-md-6">
                                <div class="embed-responsive embed-responsive-16by9 z-depth-1-half">
                                  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/A3PDXmYoF5U"
                                    allowfullscreen></iframe>
                                </div>
                              </div>
                            </div>
                          </div>

                        </div>

                        <!--Footer-->
                        <div class="modal-footer justify-content-center">
                          <button class="btn btn-danger"><span class="fa fa-heart"></span> Like</button>
                        </div>

                      </div>
                      <!--/.Content-->

                    </div>
                </div>
                <!--Modal-->


            </div>

            <div class="col-sm-12 col-md-5 text-right my-auto">
              <h2 class="">Tenant-tenant di Startup Expo 2020</h2>
            </div>

          </div>
        </div>
    </div>

    {{-- startup expo galery --}}
    <div class="container-fluid zig" id="galery">
        <div class="container intervalSection">
            <h1 class="text-center mb-5">Keseruan di Startup Expo Sebelumnya</h1>
            <div class="card-columns">
                <div class="card">
                    <img src="{{asset('myAssets/galery/IMG_8496-min.JPG')}}" class="card-img-top" alt="...">
                </div>
                <div class="card">
                  <img src="{{asset('myAssets/galery/IMG_8450-min.JPG')}}" class="card-img-top" alt="...">
                </div>
                <div class="card">
                    <img src="{{asset('myAssets/galery/IMG_8479-min.JPG')}}" class="card-img-top" alt="...">
                </div>
                <div class="card">
                    <img src="{{asset('myAssets/galery/IMG_8482-min.JPG')}}" class="card-img-top" alt="...">
                </div>
                <div class="card">
                    <img src="{{asset('myAssets/galery/IMG_8512-min.JPG')}}" class="card-img-top" alt="...">
                </div>
                <div class="card">
                    <img src="{{asset('myAssets/galery/IMG_8522-min.JPG')}}" class="card-img-top" alt="...">
                </div>
                <div class="card">
                    <img src="{{asset('myAssets/galery/IMG_8560-min.JPG')}}" class="card-img-top" alt="...">
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid bg-dark text-white" id="contact">
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-sm-3">
                    <h5>Contact us:</h5>
                    <p><span class="fa fa-envelope"></span> Gmail: blablabla@gmail.com</p>
                    <p><i class="fa fa-instagram" ></i> Instagram: @blablabla</p>
                    <p><span class="fa fa-mobile"></span> Phone: 08542369857</p>
                </div>
                <div class="col-sm-3">
                    <h5>More about us:</h5>
                    <p><span class="fa fa-chevron-right"></span> UKM Primakara</p>
                    <p><span class="fa fa-chevron-right"></span> Prodi Primakara</p>
                    <p><span class="fa fa-chevron-right" ></span> Dosen Primakara</p>
                </div>
                <div class="col-sm-3">
                    <h5>Other event:</h5>
                    <p><span class="fa fa-chevron-right"></span> PMB</p>
                    <p><span class="fa fa-chevron-right"></span> Malam Keakraban</p>
                    <p><span class="fa fa-chevron-right" ></span> Bali Startup Camp</p>
                    <p><span class="fa fa-chevron-right" ></span> XD Fiesta</p>
                </div>
                <div class="col-sm-3">
                    <h5>Location:</h5>
                    <p><span class="fa fa-map-marker" ></span> Jalan Tukad Badung</p>
                </div>
            </div>
        </div>
    </div>
    <script src="{{asset('js/app.js')}}"></script>
</body>
</html>
